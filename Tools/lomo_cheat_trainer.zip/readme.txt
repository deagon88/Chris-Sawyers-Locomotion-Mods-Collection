Locomotion Trainer v1.0 Readme
======================================
By another_lomo_player
24.11.2004

This is a trainer for Locomotion with 1.76 patch.

FUNCTIONS:
======================================
I	Quick Year Jump
II	Advance Year Jump 
III	Money Cheat
IV	Performance Index Cheat


QUICK YEAR JUMP:
Will jump fast to selected year. But you would get the new vehichles that 
has been released after you have jumped.


ADVANCE YEAR JUMP:
Most advance function. Will jump to each 26-29th december each year.
Then it will wait to 3 Januar and jump to december again.
You have to choose how many years the cycle will go. 
This will make that you can get all vehichles fast.
Each year takes around 2-6 seconds.

WARNING: While using this function, you must not use fast foreward or ultra fast foreward.
If you do that, jumping several year at once will be the result, and you will not get all the vehicles.


MONEY CHEAT:
Will give you selected amount of money extra.

PERFORMANCE INDEX CHEAT:
Change your performance index with this functions.
The index must be written in per thousand, not in per hundred(percent).
Also 50% performance index in LoMo, is 500(�) in my trainer.

SHORTCUTS:
======================================
Ctrl+M = Money Cheat
Ctrl+Y = Quick Year Jump
Ctrl+R = Performance Index Cheat
Ctrl+A = Advance Year Jump

OTHER THINGS:
======================================
The .manifest file is for xp-skin support.
Only for Xp/2000 (is not tested on win9x).

Any problems, bugs or just good ideas?
Post them here: <link to the uploadplace's forums>

Or send them to: my_personal_hotmail@hotmail.com

