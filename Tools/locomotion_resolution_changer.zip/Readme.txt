Locomotion Resolution Changer Readme
======================================
By another_lomo_player
04.01.2005

With this program you can change the resolution on 
Locomotion to a value that isn't listed up in the options in the game.
Your graphic card must support the resolution, 
else Locomotion will change back to 800x600.

MUST BE IN THE SAME FOLDER AS LOCO.EXE, IN THE LOCOMOTION FOLDER.
Else the result would be crash.

Checkout http://home.no/locomotion for updates and help.

