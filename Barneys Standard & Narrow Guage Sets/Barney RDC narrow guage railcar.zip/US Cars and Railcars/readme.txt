prdcus2.dat	RDC Railcar
pcarus4.dat	Carriage for RDC

pcarus2.dat	Passenger Carriage earlier available
pdcarus2.dat	Passenger Driving Car 

Pioneer.dat	Pioneer EMU (3rd rail electrified)
pioneerc.dat	Carriage for Pioneer
metro.dat	Metroliner, double unit (3rd rail electrified)

- please note Pioneer and Metroliner are origin overhead electrified -


Barney