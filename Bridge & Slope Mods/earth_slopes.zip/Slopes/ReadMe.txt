=== Earth Slopes for Locomotion ===

= About = 
These slopes allow trains to travel at full speed up a single level above the ground. They are only used for slopes, not bridges and must be built directly on the ground, not above it. Only straight slopes are allowed, no curved slopes.

= Installation = 
Simply place both .DAT files in your Locomotion\ObjData\ directory. You may wish to backup your original TRACKST.DAT before hand in case of any problems.
WARNING: Replacing TRACKST.DAT will mean this is the only custom bridge in the game. It you have some already installed, you will have to add this bridge manually.

= Use = 
To use the slopes in-game, it must be selected when the scenario is created. Then when trying to build a slope, select it from the drop-down bridge menu.


Copyright 2004 Stephen Brandwood of LocomotionDepot.net.