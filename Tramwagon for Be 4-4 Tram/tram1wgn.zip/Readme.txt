INSTALLATION

Unzip tram1wgn.dat to the Objdata subdirectory under the Locomotion directory. If you want
to use the wagon in existing games I have to disappoint you, that's not yet possible. Create
a scenario with the scenario-editor and include this wagon to have it available when the
Be 4/4 appears. There will be no news message announcing it (it's just there!)


CONTACT

If you find a glitch or want to share your opinion with me, PM me on www.tt-forums.net (user
name = Hyronymus) or write an email to: hyronymus@gmail.com


Thanks to Norfolk Southern for helping me locate the initial error and patchman for yet
another great tool.

