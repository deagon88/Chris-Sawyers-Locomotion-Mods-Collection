UK STEAM V3.0 README

Thank you very much for downloading this pack. It includes some of the finest steam locomotives to run in Britain and some coaching stock to go with them. All have been converted from MSTS models for use in Locomotion. I hope you enjoy using them in your games.


Notes:
The stats aren't exactly perfect, for example the power ratings are educated guesses as steam engines don't have power in HP.
The top speeds are also estimates.
All locos have 100% reliability, as personally I don't like having to replace all my trains when they start to break down too much.
Any of these locos that have survived into preservation (which fortunately many have) never become obselete.

British Company Acronyms:

BR - British Railways. Created in 1948 when the railways were nationalised.

The 'Big Four' - Created in 1923 when the 19th Century companies were grouped together into 4 larger companies along geographical lines.

GWR - Great Western Railway (Already existed pre 1923)
LNER - London North Eastern Railway
SR - Southern Railway
LMS - London Midland Scottish Railway

Pre-grouping Companies:

LBSCR - London, Brighton and South Coast Railway
SECR - South Eastern and Chatham Railway
LSWR - London South Western Railway
MR - Midland Railway


Terms of use

Feel free to edit the stats for personal use, but not for re-distribution. Do not sell these trains on to anyone, it's freeware.
I accept no responsibility for any damage to your PC or Locomotion install caused by this pack (not that it should).


Credits
 
Thanks to the following MSTS creators, without their hard work in creating the excellent MSTS models that these add-ons have been converted from, none of these trains would be possible: 
Paul Gausden (517 Class, Dean Goods, LBSCR L1, Terrier,  Autocoach, Toad Brake van, SECR Carriges)
Reg Furniss (14xx, 38xx, Castle, Hall, Large and Small Prairies, Pannier Tank, N7, B12, J15, Q1)
Tim Booth (2251 Class, Centenary Coaches)
David Ward (Re-skinned 2251 Class)
Frank Sandwell (GWR Coaches, LMS Luggage Van)
Robin Howell (City of Truro, King)
Peter Harvey (Silver Link Train, Streamlined Coronation Class, Flying Scotsman)
David Ball (Coronation Scot Carriges, LMS Express Coach)
Kevin Martin (Ivatt 2MT Tank and Tender versions)
Paul Mitchell (Britannia, 9F)
Matthew Carey (BR Standard 4MT Tender)
Phil Easton (Brake van)
Danny Gilbert (King Arthur, Merchant Navys, N15X, Royal Scot)
Richard Doling (Lord Nelson)
Richard Osborne (T9, LSWR Carriges, SR Express Coach)
Ian Morgan (M7)
Jeff Layfield (SR O2, Gladstone, LBSCR Carriges)
Dave Robinson (Tornado, S15)
Brian Walker and Dave Bran (LMS 4P)
Richard Scott (MR Johnson single, MR Express Carrige)
	  
Thanks must also go to:
Paul Gausden, for creating MSTS Shape viewer, which was used to make the animated steam locos.
Plastikman, who did the graphics for the two A4 locos and the LMS Princess Coronation class.
Owen Rudge, for creating TT-Forums 
Patchman, for creating LocoTool
The creators of MSTS 2 Loco
without whom these trains wouldn't have been possible.


I have tested these trains out and hopefully there shouldn't be any problems, but if there are then don't hesitate to get in contact with me via TT Forums (Username DJC).

TT-Forums thread, check for updates and feel free to post any constructive criticism: http://www.tt-forums.net/viewtopic.php?f=40&t=43290&start=0

Thanks,
David Chandler

