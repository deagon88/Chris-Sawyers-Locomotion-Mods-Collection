== Enhanced Airport Pack == Version 1.1 ==

== History ==

Version 1.0:
First Release

Version 1.1:
Modified Airport1 with new patch system. The planes will use the system that was newly implemented in the Locomotion Patch aswell as the smaller holding loops. 


== What it does ==

The pack contains 6 types of airports, 4 modifications of the existing airports and 2 completely new designs. The existing airports have been modified to have a smaller holding circle, to help decrease the time a plane needs to wait in order to land. 

The 2 new airports are as follows. The International Airport is a dual runway airport with 4 terminals. It offers a much more efficient system than the other airports, allowing multiple planes to be moving at once and planes can land whilst another plane takes off. Whilst there is only 4 terminals, waiting times are short due to a very efficient system, where multiple planes can be moving at one through the terminal section, without causing collisions. The second new airport is a Large Heliport, offering 4 independant landing pads. This enables 4 helicopters to use each landing pad seperately, greatly increasing the productivity of the airport and drastically lowering waiting times. If a landing pad is occupied, the helicopter will continue to circle the airport, checking each terminal in term, until it can land.


== Installation ==

Simply drop all 6 .DAT files into your Locomotion\ObjData folder. You may wish to back up your ObjData folder first, so you can replace these new files with your older ones if you need to.


== How to use ==

When creating a scenario, select the new airports from the airport list in the advanced options, they will now be buildable. You can also edit exisiting scenarios to include the airports. The modifications of the current airports are automatically applied to all your current scenarios and save games.

In a scenario with the airports enabled, simply select the desired airport from the airport list in game. The Large Heliport is available from 1962 and the International Airport from 1990. They will never become obselete.


== Notes ==

This mod may conflict with other airport altering modifications.
This took many, many attempts, a tonne of graph paper and some pretty graphs, but everything is now documented on the Wiki (wiki.locomotiondepot.net) to save you the strain.
Planes may drop quite suddenly when entering the flight path around an airport, depending on the exact angle they approach it.


== Credits ==

Steve - Made the things, praise him. Also developed initial work further, into what we know today about the airport system.
Patchman - General support and did all the initial work in decoding the airport structure.
#tycoon - Listened to me go on about it, much appreciated.
Locomotion Dev Team - For providing the system that the airport works with and supplying the graphics that have been used.


== Contacts ==

You can contact me directly at: steveb@phoenixscripts.co.uk
Or post on the forum somewhere.
