=======================================================================

Matterhorn Railways v1.2

=======================================================================
Date: 	 3.4.2015
=======================================================================
Authors: Strongbow
=======================================================================
English support: www.tt-forums.net/viewtopic.php?t=49869

Wiki: http://en.wikipedia.org/wiki/BVZ_Zermatt-Bahn

=======================================================================
Description:

The pack consists of the Matterhorn-Gotthard-Bahn and Gornergratbahn
narrow gauge railway units from Switzerland and the Ferrocarrils de la
Generalitat de Catalunya rack units from Spain that share a similar
design.

The BDSeh 4/8 EMU is available in company colours in the 1.1 release.

Changed obsolete date on the silver MGB BDSeh 4/8 in 1.2.

=======================================================================
Includes:

-MGB Trains-

MGBDS48S.dat - MGB BDSeh 4/8 adhesion/rack electric multiple unit (silver)
MGBDS48W.dat - MGB BDSeh 4/8 adhesion/rack electric multiple unit (white)

-GGB Trains-

GGBHE48O.dat - GGB Bhe 4/8 rack electric multiple unit (original condition)
GGBHE48.dat - GGB Bhe 4/8 rack electric multiple unit (after reconstruction)

-FGC Trains-

FGCA10.dat - FGC GTW Beh 2/6 rack electric multiple unit (Nuria)
FGCAM1.dat - FGC GTW Beh 2/6 rack electric multiple unit (Montserrat)

-Bonus Trains-

STADNG.dat - Stadler NG EMU in company colours (based on BDSeh 4/8)

-Sound-

SNDGTW.dat - GTW electric start sound
SNDGTWD.dat - GTW diesel start sound, blank for now and acts as placeholder
SNDGTWH.dat - GTW horn

=======================================================================
Installation:

Copy the .dat file(s) into your locomotion\objdata folder and select
the train(s) in scenario editor.

=======================================================================
How to get improved reliability or no breakdowns:

Download the Locotool Wrapper from the following location:
http://www.locomotion-fanpage.net/index.php?page=DatabaseItem&id=112

Start the program, select what version you want (improved reliability,
no breakdowns, no obsoletion, etc.) and then drag and drop the train
DAT file into the upper empty rectangle. You should get directories
with the modified DATs, simply copy them into the OBJDATA folder
and overwrite the default ones. ;)

=======================================================================
Thanks to:

Damage for help with bogies

=======================================================================
Nice rack.
